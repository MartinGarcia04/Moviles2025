import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Btn1: UIButton!
    @IBOutlet weak var Btn02: UIButton!
    @IBOutlet weak var Btn03: UIButton!
    @IBOutlet weak var Btn04: UIButton!
    @IBOutlet weak var Btn05: UIButton!
    @IBOutlet weak var Btn06: UIButton!
    @IBOutlet weak var Btn07: UIButton!
    @IBOutlet weak var Btn08: UIButton!
    @IBOutlet weak var Btn09: UIButton!
    
    var currentPlayer = "X" // Variable para determinar el jugador actual
    var gameBoard = ["", "", "", "", "", "", "", "", ""] // Array que representa el tablero de juego
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Inicializa todos los botones
        resetBoard()
    }
    
    // Función que resetea el tablero
    func resetBoard() {
        gameBoard = ["", "", "", "", "", "", "", "", ""]
        
        // Reseteamos el título de todos los botones
        Btn1.setTitle("", for: .normal)
        Btn02.setTitle("", for: .normal)
        Btn03.setTitle("", for: .normal)
        Btn04.setTitle("", for: .normal)
        Btn05.setTitle("", for: .normal)
        Btn06.setTitle("", for: .normal)
        Btn07.setTitle("", for: .normal)
        Btn08.setTitle("", for: .normal)
        Btn09.setTitle("", for: .normal)
    }
    
    // Acción para cada botón del juego
    @IBAction func btnTapped(_ sender: UIButton) {
        let index: Int
        
        // Identificar el índice del botón en el tablero
        switch sender {
        case Btn1:
            index = 0
        case Btn02:
            index = 1
        case Btn03:
            index = 2
        case Btn04:
            index = 3
        case Btn05:
            index = 4
        case Btn06:
            index = 5
        case Btn07:
            index = 6
        case Btn08:
            index = 7
        case Btn09:
            index = 8
        default:
            return
        }
        
        // Solo se permite jugar si la casilla está vacía
        if gameBoard[index] == "" {
            gameBoard[index] = currentPlayer
            sender.setTitle(currentPlayer, for: .normal)
            
            if checkWinner() {
                showWinnerAlert()
            } else if checkDraw() {
                showDrawAlert()
            } else {
                currentPlayer = currentPlayer == "X" ? "O" : "X" // Cambiar de jugador
            }
        }
    }
    
    // Comprobar si hay un ganador
    func checkWinner() -> Bool {
        let winningCombinations = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6]
        ]
        
        for combination in winningCombinations {
            let (a, b, c) = (gameBoard[combination[0]], gameBoard[combination[1]], gameBoard[combination[2]])
            if a != "", a == b, a == c {
                return true
            }
        }
        return false
    }
    
    // Comprobar si el juego ha terminado en empate
    func checkDraw() -> Bool {
        // Si el tablero está lleno y no hay ganador
        return !gameBoard.contains("") // Retorna true si no hay espacios vacíos
    }
    
    // Mostrar alerta de ganador
    func showWinnerAlert() {
        let alert = UIAlertController(title: "¡Ganador!", message: "El jugador \(currentPlayer) ha ganado!", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Aceptar", style: .default) { _ in
            self.resetBoard()
        }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    // Mostrar alerta de empate
    func showDrawAlert() {
        let alert = UIAlertController(title: "¡Empate!", message: "El juego ha terminado en empate.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Aceptar", style: .default) { _ in
            self.resetBoard()
        }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    // Acción para el botón de reiniciar el juego
    @IBAction func resetButtonTapped(_ sender: Any) {
        resetBoard()
    }
}

